@echo off
setlocal
cd /d "%~dp0"
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" goto missing
for /f "usebackq delims=" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.Component.MSBuild Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VS=%%i"
if not defined VS goto missing
call "%VS%\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64
if errorlevel 1 goto failed
msbuild Mesen.sln /restore /m /p:Configuration=Release /p:Platform=x64
if errorlevel 1 goto failed
if not exist "bin\win-x64\Release\Mesen.exe" goto failed
echo Build finished: bin\win-x64\Release\Mesen.exe
pause
exit /b 0
:missing
echo Visual Studio 2022 C++ desktop workload is required.
:failed
echo Build not completed. Check the output above.
pause
exit /b 1
